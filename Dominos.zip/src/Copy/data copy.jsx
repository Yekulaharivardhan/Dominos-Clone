


const data = {
  productData: [
    {
      id: 1,
      img:"https://images.dominos.co.in/Paneer.jpg",
      title: "Paneer Paratha Pizza",
      desc: "An epic fusion of paratha and pizza with melting cheese & soft paneer fillings to satisfy all your indulgent cravings",
      price: 46,
    },
    {
      id: 2,
      img: "https://images.dominos.co.in/Keema.jpg",
      title: "Paneer Paratha Pizza",
      desc: "Flavourful Paneer paratha and goodness of cheesy pizza coming together in an epic crossover!",
      price: 56,
    },
    {
      id: 3,
      img: "https://images.dominos.co.in/CMB1250.jpg",
      title: "Chicken Keema Paratha Pizza",
      desc: "Flavourful & meaty chicken keema paratha and goodness of cheesy pizza coming together in an epic crossover!",
      price: 66,
    },
    {
      id: 4,
      img: "https://images.dominos.co.in/CMB1251.jpg",
      title: "Value Combo: 2 Choco Lava Cake",
      desc: "Value Combo: 2 Choco Lava Cake @ 99 Each",
      price: 66,
    },
    {
      id: 5,
      img: "https://images.dominos.co.in/new_margherita_2502.jpg",
      title: "Margherita",
      desc: "Classic delight with 100% real mozzarella cheese",
      price: 66,
    },
    {
      id: 6,
      img: "https://images.dominos.co.in/new_margherita_2502.jpg",
      title: "Margherita",
      desc: "Classic delight with 100% real mozzarella cheese",
      price: 66,
    },
    {
      id: 7,
      img: "https://images.dominos.co.in/new_margherita_2502.jpg",
      title: "Margherita",
      desc: "Classic delight with 100% real mozzarella cheese",
      price: 66,
    },
    {
      id: 8,
      img: "https://images.dominos.co.in/new_margherita_2502.jpg",
      title: "Margherita",
      desc: "Classic delight with 100% real mozzarella cheese",
      price: 66,
    },
  ],
};
export default data;