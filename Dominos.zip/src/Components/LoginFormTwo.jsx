import React, { Component, } from 'react';
import {Link} from 'react-router-dom'


    
 class FormField extends Component {
    
    
    state   = {
        account: {mobilenumber:''},
        disabled: true
     };
     

    valiDation = e => {
        console.log(e)
        e.preventDefault();
        if(e.target[1].value >= 10  && e.target[1].value.match(/[0-9]/)){
            console.log(e.target[1].value)
             this.props.history.push('/placeOrderCode')
          

            }
            else {
                alert("failed to login")
                }
         

        }
      


        handlebutton =(e) =>{
console.log(e)
            if(e.target.value.length >=10 ){
document.getElementById("submmitbutton").style.backgroundColor="green"
                this.setState({ disabled: false });
            }
            else{
                document.getElementById("submmitbutton").style.backgroundColor="gray"
                this.setState({ disabled: true });
            }
        }
      

         


      render() {
        
        return (
          


          <form onSubmit={this.valiDation} >
            <div className="login_controls">
              <div className="sc-iAyFgw login_divclass">
              <Link to ="/placeOrderCode">jlkhbn</Link>

                <input
                  type="text"
                  placeholder="+91"
                  className=""
                  data-label="+91"
                />
              </div>
              <span className="login_controls_inpt-txt">Mobile Number</span>
              <div
                className="sc-iAyFgw mobile_number_input"
                data-label="login-mobileNumber"
              >
   
    
                <input  onChange={this.handlebutton} id="mobilenumber"   className="loginNumber"  type="text"  maxLength="10" />
                 
    
              </div>
              
            
            </div>
            <div className="sc-iAyFgw submit_butn_class" >
              <button id='submmitbutton' type="submit" className="non-empty"  disabled= {this.state.disabled} style={{backgroundColor:"gray"}}>  SUBMIT </button>
            </div>
            
          </form>
        );
      }
    }
    // export default  withRouter(FormField)

    export default  FormField