import React from 'react';
//  import './card.css'
import './itemcard.css'
import { useCart } from 'react-use-cart';





const ItemCard = (props) =>{
  const {
    addItem,
    isEmpty,
    item,
    updateItemQuantity,
    totalUniqueItems,

  } = useCart();



  
// const  customeButton = {addItem} <= 0 ?  CustomeStyle : CustomeStyleTwo

 
  


  // if(isEmpty) 

  



//   CustomeStyle = (<div className="itm-dsc__actn__adCrt">
//   <div className="injectStyles-sc-1jy9bcf-0 jrxrSi">
//   <button data-label="addTocart">
//   <span>ADD TO CART</span></button></div></div>)



//   CustomeStyleTwo = (
//    <div className="itm-dsc__actn__adCrt">
//              <div className="sc-kAzzGY beBJOM" data-label="quantity">
//              <div className="injectStyles-sc-1jy9bcf-0 kYAlCU" data-label="decrease"  onClick={() => updateItemQuantity(item.id, item.quantity -1)} >--</div>
//              <span className="cntr-val">{addItem.value}</span>
//              <div>
//              <div className="injectStyles-sc-1jy9bcf-0 gwKvJy" data-label="increase">++</div></div></div>
//            </div> )
 
//  MyStyle = {totalUniqueItems <0 ? CustomeStyle : CustomeStyleTwo}







   

  // const CartUpdStatus =
  // ItemCard <= 0 ?  CustomeStyle : CustomeStyleTwo


  


  

    return(




      

<div className="col-11 col-md-1 col-md-4 p-1" style={{marginBottom:"-30px", marginRight:"-30px"}}>
  <div className='card shadow-lg  mb-1  bg-body rounded' style={{width: "15rem",}}>
  <div className="cardtop" style={{position:"relative"}}>
<img className="card-img-top " src={props.img} alt=" " style={{width:"100%"}} />
<div className="card-title" style={{position:"absolute", bottom:"-6px", left:"16px",color:"white",fontWeight:"bolder"}}>₹{props.price}</div>
</div>
  <div className="card-body " >
    <h5 className="card-title">{props.title}</h5>
    <p className="card-text" style={{fontSize:"13px"}}>{props.desc}</p>









    <button id='addtocart' type="button" className="btn btn-outline border-success btn-sm"  onClick={() =>addItem(props.item)} ><p>ADD TO CART</p>
    
    </button>
  </div></div></div>
 
    )
//  =========================================================================================        




// return ( 
  


// <div>
  
//     {items.map((item) => (
//   <div>
//       <div className='cartsectiondiv' style={{ paddingTop:"5%", paddingLeft:"5%",fontSize: "1rem",}} >
//      <div className='' key={item.id} style={{}}>   
//     <div className='crt-cnt-img'  >
//   <img  src={item.img} style={{width:"40%", height:"60px", borderRadius:"10px"}} alt='' />
//   </div>
//   <div className='crt-cnt-descrptn-ttl' style={{fontSize: "0.9rem"}}>{item.title}</div>
//   <div className='crt-cnt-descrptn-desc' style={{ fontSize: "0.7rem",width:"90%"}}>{item.desc}</div>
//                         </div>
 
//      <div className="btn-toolbar justify-content-between" role="toolbar" aria-label="Small button groups" style={{height:"27px", paddingBottom:"5px"}}>
//     <div className="btn-group btn-grou-sm mb-2" role="group" aria-label="First group" style={{height:"25px", marginTop:"5px"}}>
//    <button type="button" className="btn btn-outline-secondary"   onClick={() => updateItemQuantity(item.id, item.quantity -1)} ><span style={{marginTop:"-187px"}}>-</span></button>
//    <button type="button" className="btn btn-outline-secondary"> <span style={{marginTop:"-180px", fontSize:"0.9em"}}>{item.quantity}</span></button>
//     <button type="button" className="btn btn-outline-secondary"  onClick={() => updateItemQuantity(item.id, item.quantity +1)}><span style={{marginTop:"-185px",transition: "all 1s ease 0s"}}>+</span></button>
//     </div></div></div></div>

//    )
//    )
//     }
                  
                        
//                   </div>   
//     )
}

export default ItemCard