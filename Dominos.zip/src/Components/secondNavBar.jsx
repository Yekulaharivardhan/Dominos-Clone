import React from "react";
import "./secondNavBar.css";
import "./card.css";




const Image = "https://images.dominos.co.in/Paneer.jpg";
const img2 = "https://images.dominos.co.in/4625-CMB1211.jpg";
const img3 = "https://images.dominos.co.in/CMB1250.jpg";
const img4 = "https://images.dominos.co.in/PIZ5158_1.jpg";
const img5 = "https://images.dominos.co.in/PIZ0171.jpg";
const img6 = "https://images.dominos.co.in/PIZ5160_1.jpg";

const SecondNavBar = () => {
  return (
    <div>
    
      <div className="sc-htpNat esboMF">
        <nav id="navbar-example2" className="navbar navbar bg">
          <div className="mn-hdr hide" data-label="Everyday Value">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-1"
            >
              EVERYDAY VALUE
            </a>
          </div>

          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-2"
            >
              BESTSELLERS
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-3"
            >
              NEW LAUNCHES
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-4"
            >
              PARATHA PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-5"
            >
              VEG PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-6"
            >
              BEVERAGES
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-7"
            >
              NON-VEG PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-8"
            >
              CHICKEN LOVERS PIZZA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-9"
            >
              SPECIALITY CHICKEN
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-10"
            >
              SIDES
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-11"
            >
              PIZZA MANIA
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-12"
            >
              MEAL FOR 1
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-13"
            >
              MEAL FOR 2
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-14"
            >
              MEAL FOR 4
            </a>
          </div>
          <div className="mn-hdr hide">
            <a 
              className="list-group-item list-group-item-action"
              href="#list-item-15"
            >
              PARTY COMBOS
            </a>
          </div>
          <div className="mn-hdr hide"></div>
        </nav>
      </div>

      

      <div
        data-spy="scroll"
        data-target="#list-example"
        data-offset="0"
        className="scrollspy-example"
      >
      
        <h4 id="list-item-1" style={{ marginTop: "80px" }}>
        
        <div className="ref">
        <div className="menu-hr"></div>
        <div className="cat-bar">
          <div className="menu-catname ">EVERYDAY VALUE</div>
        </div>
      </div>

        </h4>




<div id="cardnumberone">
        <div className="cardwrap">
          <div className="card" id="cardone">
            <img className="card-img-top" src=" " alt=" " />
            <div className="card-body">


              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              
              <Counter/> 
            </div>
          </div>
          



          <div id="cardnumbertwo">
          <div className="card" id="cardtwo">
            <img className="card-img-top" src={"https://images.dominos.co.in/4625-CMB1211.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div></div>

          <div className="card" id="cardthree">
            <img className="card-img-top" src={"https://images.dominos.co.in/Corn.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card" id="cardfour">
            <img className="card-img-top" src={"https://images.dominos.co.in/Paneer.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card" id="cardfour">
            <img className="card-img-top" src={"https://images.dominos.co.in/CMB1250.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card" id="cardfive">
            <img className="card-img-top" src={"https://images.dominos.co.in/CMB1251.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
             <Counter/>
            </div>
          </div>

          <div className="card" id="cardsix">
            <img className="card-img-top" src={"https://images.dominos.co.in/CMB1253.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/CMB1253.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/new_veg_extravaganza.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/new_peppy_paneer.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/new_chicken_sausage.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          
        </div>
        <h4 id="list-item-2">BEST SELLERS</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
             <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
             <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>

        <h4 id="list-item-3">NEW LAUNCHES</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>
        <h4 id="list-item-4">PARATHA PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>
        <h4 id="list-item-5">VEG PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>

        <h4 id="list-item-6">BEVERAGES</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/BEV0119_1.jpg"} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/7up_new_2202.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/mirinda.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/pepsi_black.png"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/ALPHONSO.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PINKGUAVA.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/MIXEDFRUIT.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/BailleyONE.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/BEV0124.png"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>

        <h4 id="list-item-7">NON-VEG PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/CreamyTomatoPPNV_N.jpg"} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/MoroccanSpicePPNV_N.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/Keema.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/new_chicken_dominator.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PIZ5157_1.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PIZ5158_1.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PIZ5159_1.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PIZ5160_1.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/new_chicken_golden_delight.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          
        </div>

        <h4 id="list-item-8">CHICKEN LOVERS PIZZA</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PIZ5157_1.jpg"} alt=" " />

            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PIZ5160_1.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/PIZ5158_1.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          
        </div>

        <h4 id="list-item-9">SPECIALITY CHICKEN</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/Roasted-chicken.png"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/Roasted-chicken.png"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/Chicken-Meat-balls.png"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/chicken_meatballs_peri_peri_sauce.jpg"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={"https://images.dominos.co.in/Boneless-Chicken-wings.png"} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          
        </div>

        <h4 id="list-item-10">PARTY COMBOS</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>
        <h4 id="list-item-12">MEAL FOR 1</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>

        <h4 id="list-item-13">MEAL FOR 2</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>

        <h4 id="list-item-14">MEAL FOR 4</h4>
        <div className="cardwrap">
          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img5} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img3} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={Image} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img2} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img4} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>

          <div className="card">
            <img className="card-img-top" src={img6} alt=" " />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
              <Counter/>
            </div>
          </div>
        </div>
      </div>

      
    </div>

   
  </div>
    //       <div className="collapse navbar-collapse" id="navbarNav">
    //         <ul className="navbar-nav">
    //           <li className="nav-item active">
    //             <NavLink className="nav-link" to="#">
    //               BESTSELLERS <span className="sr-only">(current)</span>
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               NEW LAUNCHES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PARATHA PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               VEG PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               BEVERAGES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               NON-VEG PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               CHICKEN LOVERS PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               SPECIALITY CHICKEN
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               SIDES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PIZZA MANIA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 1
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 2
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 3
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 4
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PARTY COMBOS
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               DESSERT
    //             </NavLink>
    //           </li>
    //         </ul>
    //       </div>
    //     </nav>
    //   </div>

    /* <div className="sc-htpNat esboMF">
        <div className="mn-hdr hide" data-label="Everyday Value">
          <span>EVERYDAY VALUE</span>
        </div>
        <div className="mn-hdr active" data-label="Bestsellers">
          <span>BESTSELLERS</span>
        </div>
        <div className="mn-hdr hide" data-label="New Launches">
          <span>NEW LAUNCHES</span>
        </div>
        <div className="mn-hdr hide" data-label="Paratha Pizza">
          <span>PARATHA PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Veg Pizza">
          <span>VEG PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Beverages">
          <span>BEVERAGES</span>
        </div>
        <div className="mn-hdr hide" data-label="Non-Veg Pizza">
          <span>NON-VEG PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Chicken Lovers Pizza">
          <span>CHICKEN LOVERS PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Speciality Chicken">
          <span>SPECIALITY CHICKEN</span>
        </div>
        <div className="mn-hdr hide" data-label="Sides">
          <span>SIDES</span>
        </div>
        <div className="mn-hdr hide" data-label="Pizza Mania">
          <span>PIZZA MANIA</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 1">
          <span>MEAL FOR 1</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 2">
          <span>MEAL FOR 2</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 4">
          <span>MEAL FOR 4</span>
        </div>
        <div className="mn-hdr hide" data-label="Party Combos">
          <span>PARTY COMBOS</span>
        </div>
        <div className="mn-hdr hide" data-label="Dessert">
          <span>DESSERT</span>
        </div>
      </div> }
    </React.Fragment>*/
  );
};

export default SecondNavBar;
