import React, { Component } from "react";
import ItemCard from "./itemcard";
// import './card.css'
import data from "./data";





class HomePage extends Component {
  state = {};
  render() {
    return (
      
        
      <div className="container-sm gx-5" style={{marginTop:"-90px",marginLeft:"-65px",height:"80%"}}>
      <div className="row mr-5">
         
            {data.productData.map((item) => {
              return (
                <ItemCard
                  key={item.id}
                  img={item.img}
                  title={item.title}
                  desc={item.desc}
                  // price={item.price}
                  item={item}
                  
                />
                
              );
            })}
            
            </div>
            </div>
            

    );
  }
}

export default HomePage;
